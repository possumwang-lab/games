import asyncio

from river_crossing_game import main


asyncio.run(main())
